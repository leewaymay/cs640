#!/bin/bash

cd pox_module
sudo python setup.py develop
